from .didppy import *

__doc__ = didppy.__doc__
if hasattr(didppy, "__all__"):
    __all__ = didppy.__all__